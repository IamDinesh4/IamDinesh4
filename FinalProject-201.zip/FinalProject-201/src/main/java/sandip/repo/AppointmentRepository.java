package sandip.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import sandip.model.Appointment;

public interface AppointmentRepository extends JpaRepository<Appointment, Integer>
{

}
