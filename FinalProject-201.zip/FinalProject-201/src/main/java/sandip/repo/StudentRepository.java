package sandip.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import sandip.model.Feedback;

public interface StudentRepository extends JpaRepository<Feedback, Integer>
{

}
