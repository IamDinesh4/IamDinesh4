package sandip.util;

import org.springframework.stereotype.Component;

import sandip.model.Appointment;

@Component
public class AppointmentUtil2 {

	public void mapToActualObject(Appointment actual, Appointment appointment) {
		if(appointment.getName()!=null)
			actual.setName(appointment.getName());
		actual.setCovidreports(appointment.getCovidreports());
		actual.setVacstatus(appointment.getVacstatus());
		actual.setPhnumber(appointment.getPhnumber());
		if(appointment.getEmail()!=null)
			actual.setEmail(appointment.getEmail());
		actual.setTimeslot(appointment.getTimeslot());
	}

}
