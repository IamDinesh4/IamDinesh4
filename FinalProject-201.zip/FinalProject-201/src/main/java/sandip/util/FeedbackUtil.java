package sandip.util;

import org.springframework.stereotype.Component;

import sandip.model.Feedback;

@Component
public class FeedbackUtil {

	public void mapToActualObject(Feedback actual, Feedback feedback) {
		if(feedback.getName()!=null)
			actual.setName(feedback.getName());
		actual.setComments(feedback.getComments());
		actual.setRating(feedback.getRating());
		actual.setPhnumber(feedback.getPhnumber());
		if(feedback.getEmail()!=null)
			actual.setEmail(feedback.getEmail());
		actual.setAddr(feedback.getAddr());
	}

}
